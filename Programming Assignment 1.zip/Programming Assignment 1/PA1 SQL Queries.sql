SELECT employees.lastName, employees.firstName

FROM employees JOIN customers

ON employees.employeeNumber = customers.salesRepEmployeeNumber

WHERE customers.customerName = "user_input";

/*
This query returns the name of the employee(s) that is (are) assigned to a given customer (identified by name).
*/



SELECT COUNT(*)

FROM customers JOIN orders
ON customers.customerNumber = orders.customerNumber

WHERE customers.country = "user_input";

/*
This query returns the number of orders (by number of order numbers) to a given country.
*/ 


SELECT firstName, lastName, email 
FROM employees

WHERE jobTitle = "Sales Rep";

/*
This query selects the name and e-mail of all sales representatives.
*/


SELECT AVG(amount)
FROM payments;

/*
This query returns the average amount of all payments made to the company.
*/

SELECT DISTINCT productlines.productLine, productlines.textDescription
FROM customers JOIN orders JOIN orderdetails JOIN products JOIN productlines
ON (customers.customerNumber = orders.customerNumber 
AND orders.orderNumber = orderdetails.orderNumber
AND orderdetails.productCode = products.productCode
AND products.productLine = productlines.productLine)
WHERE customers.customerName = "user_input";

/*
This query returns all product lines from which a given customer has ordered.
*/


SELECT city, state, country, territory
FROM offices JOIN employees
ON employees.officeCode = offices.officeCode
WHERE employees.jobTitle = "President";

/*
This query returns the city, state, country, and territory of the office at which the company's President works.
*/



SELECT contactFirstName, contactLastName
FROM customers JOIN orders
ON customers.customerNumber = orders.customerNumber
WHERE orderNumber = "user_input";

/*
This query returns the name of the contact that placed a given order(based on order number).
*/

SELECT status
FROM customers JOIN orders
ON customers.customerNumber = orders.customerNumber
WHERE contactFirstName = "user_input_A" AND contactLastName = "user_input_B";

/*
This query returns the status of any orders from a given contact.
*/